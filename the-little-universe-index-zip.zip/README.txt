THE LITTLE UNIVERSE — GITHUB PAGES UPLOAD

This ZIP contains the complete self-contained website.

IMPORTANT:
1. Extract this ZIP on your computer.
2. Open the extracted folder. It contains index.html.
3. In your GitHub repository (the-little-universe), choose Add file > Upload files.
4. Upload index.html directly to the repository root (not inside another folder).
5. Commit the upload to the main branch.
6. In Settings > Pages, use Deploy from a branch, main, /(root), if not already configured.
7. Visit: https://kg496153-bit.github.io/the-little-universe/

The photos and Khat audio are embedded in index.html. Do not rename it or upload it inside a nested folder.
